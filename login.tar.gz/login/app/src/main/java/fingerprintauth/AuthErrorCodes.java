package fingerprintauth;

/**
 * Created by kishori on 12/4/18.
 */

public class AuthErrorCodes {


    public static final int RECOVERABLE_ERROR = 843;

    public static final int NON_RECOVERABLE_ERROR = 566;

    public static final int CANNOT_RECOGNIZE_ERROR = 456;
}
